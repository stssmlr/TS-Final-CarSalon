﻿namespace Core.Dtos
{
    public class UserTokens
    {
        public string RefreshToken { get; set; }
        public string AccessToken { get; set; }
    }
}
